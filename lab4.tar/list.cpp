#include "list.h"
#include <iostream>

using namespace std;
// My node and List constructors and destructor were given by Dr. Emrich's notes.
Node::Node(int i) {
	data = i;
	next = NULL;
}
List::List() {
	head = NULL;
	count = 0;
}
List::~List() {
	if (!empty()) {
		Node *p = head;

		while (p != NULL) {
			Node *next = p->next;
			delete p;
			p = next;
		}
	}
}
Node *List::newNode(int i) {
	Node *node = new Node(i);
	return node;
}
// This was more or less derived from Dr. Emrich's notes with the 
// addition of a node counter, same as the new node member.
void List::addNode(int i) {
	Node *nn = newNode(i);
	count += 1;

	if (empty()) {
		head = nn;
	} else {
		Node *p = head;
		while (p->next != NULL) {
			p = p->next;
		}
		p->next = nn;
	}
	nn->next = NULL;
}
bool List::empty() {
	if (head == NULL) {
		return true;
	} else {
		return false;
	}
}
int List::getCount() {
	return count;
}
Node *List::getHead() {
	return head;
}
// My print function puts the node data into an array and 
// outputs them backwards, rather than going backwards through a list.
void List::print() {
	int arr[count];
	int i = 0;
	if (!empty()) {
		Node *p = head;
		while (p != NULL) {
			arr[i] = p->data;
			p = p->next;
			i++;
		}

	} else {
		cout << "empty" << endl;
		return;
	}
	for (int i = count - 1;i >= 0;i--) {
		cout << arr[i];
	}
}
